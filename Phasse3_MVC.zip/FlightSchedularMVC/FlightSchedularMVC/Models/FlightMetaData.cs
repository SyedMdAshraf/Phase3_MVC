﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FlightSchedularMVC.Models
{
    public class FlightMetaData
    {
        
        public int FlightNo { get; set; }
        
        public string FlightName { get; set; }
        
        public string Destination { get; set; }
        
        public Dept Departure { get; set; }

        public string Terminal { get; set; }

        public int GateNo { get; set; }

        public string Status { get; set; }

        public class Dept
        {
            public DateTime Scheduled { get; set; }

            public DateTime Estimated { get; set; }

            public DateTime Actual { get; set; }
        }

    }
}