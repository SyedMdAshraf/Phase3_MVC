﻿create table Car_46004683_mvc
(
	ID int Identity(100,1) primary key,
	Model varchar(50) unique,
	Manufacturer_46004683_mvc int foreign key references Manufacturer_46004683_mvc (ID),
	CarType_46004683_mvc int foreign key references CarType_46004683_mvc (ID),
	Engine varchar(50),
	BHP int,
	CarTransmissionType_46004683_mvc int foreign key references CarTransmissionType_46004683_mvc (ID),
	Milage int not null,
	Seat int not null,
	AirbagDetails varchar(50) not null,
	BootSpace int not null,
	Price int not null
)

create table Manufacturer_46004683_mvc
(
	ID int primary key identity(1000,1),
	ManufacturerName varchar(50) unique,
	ContactPerson varchar(50) unique,
	RegisteredOffice varchar(50) not null
)

create table CarType_46004683_mvc
(	
	ID int primary key identity(1000,1),
	CarType varchar(50) unique
)
create table CarTransmissionType_46004683_mvc
(	
	ID int primary key identity(1000,1),
	TransmissionName varchar(50) unique
)

insert into CarType_46004683_mvc values ('Hatchback')
insert into CarType_46004683_mvc values ('Sedan')
insert into CarType_46004683_mvc values ('SUV')
insert into CarTransmissionType_46004683_mvc values ('Manual')
insert into CarTransmissionType_46004683_mvc values ('Automatic')

create procedure CIMSinsert_46004683
(
	@Model varchar(50),
	@Engine varchar(50),
	@BHP int,
	@Milage int,
	@Seat int,
	@AirBagDetails varchar(50),
	@BootSpace int,
	@Price int,
	@ManufacturerName varchar(50),
	@ContactPerson varchar(50),
	@RegisteredOffice varchar(50),
	@CarType varchar(50),
	@TransmissionType varchar(50)
)
As
begin
insert into Manufacturer_46004683 values (@ManufacturerName,@ContactPerson,@RegisteredOffice)
insert into Car_46004683 (Model,ManufacturerId,TypeId,Engine,BHP,TransmissionId,Milage,Seat,AirbagDetails,BootSpace,Price) values (@Model,(select ID from Manufacturer_46004683 where @ManufacturerName=ManufacturerName),(select ID from CarType_46004683 where @CarType=CarType),@Engine,@BHP,(select ID from CarTransmissionType_46004683 where @TransmissionType=TransmissionName),@Milage,@Seat,@AirBagDetails,@BootSpace,@Price)
end
exec CIMSinsert_46004683
create procedure CIMSdelete_46004683
(
	@Model varchar(50)
)
AS
begin 
delete from Manufacturer_46004683 where ID=(select ManufacturerId from Car_46004683 where @Model=Model)
delete from Car_46004683 where @Model=Model
end


create procedure CIMSsearch_46004683
(
	@Model varchar(50)
)
As
begin
select * from Car_46004683 FULL OUTER JOIN Manufacturer_46004683 on (ManufacturerId=(select ManufacturerId from Car_46004683 where Model= @Model ))
where Model=@Model
end

create procedure CIMSlist_46004683
(
	@ManufacturerName varchar(50),
	@CarType varchar(50)
)
As
Begin
select * from Car_46004683 FULL OUTER JOIN Manufacturer_46004683 on ((ManufacturerId=(select ID from Manufacturer_46004683 where ManufacturerName=@ManufacturerName))and(TypeId=(select ID from CarType_46004683 where CarType=@CarType)))
where ManufacturerName=@ManufacturerName

end
exec CIMSlist_46004683 @ManufacturerName='Vijay',@CarType='Sedan'
select * from CarType_46004683
create procedure CIMSupdate_46004683
(
	@Model varchar(50),
	@Engine varchar(50),
	@BHP int,
	@Milage int,
	@Seat int,
	@AirBagDetails varchar(50),
	@BootSpace int,
	@Price int,
	@ManufacturerName varchar(50),
	@ContactPerson varchar(50),
	@RegisteredOffice varchar(50),
	@CarType varchar(50),
	@TransmissionType varchar(50)
)
as
begin
update Car_46004683
set Engine=@Engine,BHP=@BHP,Milage=@Milage,Seat=@Seat,AirbagDetails=@AirBagDetails,BootSpace=@BootSpace,Price=@Price
where @Model=Model

update Manufacturer_46004683
set ManufacturerName=@ManufacturerName,ContactPerson=@ContactPerson,RegisteredOffice=@RegisteredOffice
where (select ManufacturerId from Car_46004683 where @Model=Model)=ID

update CarType_46004683
set CarType=@CarType
where((select TypeId from Car_46004683 where @Model=Model)=ID)

update CarTransmissionType_46004683
set TransmissionName=@TransmissionType
where ((select TransmissionId from Car_46004683 where @Model=Model)=ID)
end


exec CIMSlist_46004683 @ManufacturerName='Tata',@CarType='Hatchback'
drop procedure CIMSsearch_46004683
create procedure CIMSsearch_46004683
(
	@Model varchar(50)
)
As
begin
select * from Car_46004683 a, Manufacturer_46004683 b 
where a.Model=@Model and b.ID=a.ManufacturerId
end
exec CIMSsearch_46004683 @Model='tiago'
select * from Car_46004683
select * from Manufacturer_46004683
delete from Manufacturer_46004683
create procedure CIMSdelete_46004683
(
	@Model varchar(50)
)
AS
begin 
delete from Manufacturer_46004683 where ID=(select ManufacturerId from Car_46004683 where @Model=Model)
delete from Car_46004683 where @Model=Model
end
exec CIMSdelete_46004683 @Model='tiago'

create procedure CIMSupdate_46004683
(
	@Model varchar(50),
	@Engine varchar(50),
	@BHP int,
	@Milage int,
	@Seat int,
	@AirBagDetails varchar(50),
	@BootSpace int,
	@Price int,
	@ManufacturerName varchar(50),
	@ContactPerson varchar(50),
	@RegisteredOffice varchar(50),
	@CarType varchar(50),
	@TransmissionType varchar(50)
)
as
begin
update Car_46004683
set Engine=@Engine,BHP=@BHP,Milage=@Milage,Seat=@Seat,AirbagDetails=@AirBagDetails,BootSpace=@BootSpace,Price=@Price,TypeId=(select ID from CarType_46004683 where CarType=@CarType),TransmissionId=(select ID from CarTransmissionType_46004683 where TransmissionName=@TransmissionType)
where @Model=Model

update Manufacturer_46004683
set ManufacturerName=@ManufacturerName,ContactPerson=@ContactPerson,RegisteredOffice=@RegisteredOffice
where (select ManufacturerId from Car_46004683 where @Model=Model)=ID
end
alter table Car_46004683_mvc
ADD CONSTRAINT Manufacturer_Table_mvc
        FOREIGN KEY  (Manufacturer_46004683_mvc)
        REFERENCES  Manufacturer_46004683_mvc (ID)
        ON DELETE CASCADE ;
		
alter table Car_46004683_mvc
ADD CONSTRAINT Transmisson_Table_mvc
        FOREIGN KEY  (CarTransmissionType_46004683_mvc)
        REFERENCES  CarTransmissionType_46004683_mvc (ID)
        ON DELETE CASCADE ;
		
alter table Car_46004683_mvc
ADD CONSTRAINT Type_Table_mvc
        FOREIGN KEY  (CarType_46004683_mvc)
        REFERENCES  CarType_46004683_mvc (ID)
        ON DELETE CASCADE ;

delete from Manufacturer_46004683

select * from Car_46004683