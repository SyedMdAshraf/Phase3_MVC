﻿using CarManagemenetSystemMVC.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity;
namespace CarManagemenetSystemMVC.Controllers
{
    public class CarController : Controller
    {
        Training_13Aug19_PuneEntities2 dbcar = new Training_13Aug19_PuneEntities2();
        // GET: Car
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult AddCar()
        {
            ViewBag.CarTransmissionType_46004683_mvc = new SelectList(dbcar.CarTransmissionType_46004683_mvc,"ID", "TransmissionName");
            ViewBag.CarType_46004683_mvc = new SelectList(dbcar.CarType_46004683_mvc,"ID", "CarType");
            return View();
        }
        [HttpPost]
        public ActionResult AddCar([Bind(Include = "ManufacturerName,ContactPerson,RegisteredOffice")] Manufacturer_46004683_mvc manufacturer_46004683_mvc, [Bind(Include = "Model,CarType_46004683_mvc,Engine,BHP,CarTransmissionType_46004683_mvc,Milage,Seat,AirbagDetails,BootSpace,Price")] Car_46004683_mvc car_46004683_mvc)
        {
            if(ModelState.IsValid)
            {
                dbcar.Manufacturer_46004683_mvc.Add(manufacturer_46004683_mvc);
                car_46004683_mvc.ManufactureId = manufacturer_46004683_mvc.ID;
                dbcar.Car_46004683_mvc.Add(car_46004683_mvc);
                dbcar.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.CarTransmissionType_46004683_mvc = new SelectList(dbcar.CarTransmissionType_46004683_mvc, "ID", "TransmissionName",car_46004683_mvc.CarTransmissionType_46004683_mvc);
            ViewBag.CarType_46004683_mvc = new SelectList(dbcar.CarType_46004683_mvc, "ID", "CarType");
            return View(car_46004683_mvc);
        }

        public ActionResult SearchCar(string model)
        {
            if (model != null)
            {
                List<Car_46004683_mvc> car = new List<Car_46004683_mvc>();
                car = dbcar.Car_46004683_mvc.Where(e => e.Model == model).ToList();
                return View(car[0]);
            }
            return View();
        }
        public ActionResult ModifyCar(string model)
        {
            List<Car_46004683_mvc> car = new List<Car_46004683_mvc>();
            if (model != null)
            {
                
                car = dbcar.Car_46004683_mvc.Where(e => e.Model == model).ToList();
               
                ViewBag.CarTransmissionType_46004683_mvc = new SelectList(dbcar.CarTransmissionType_46004683_mvc, "ID", "TransmissionName", car[0].CarTransmissionType_46004683_mvc);
                ViewBag.CarType_46004683_mvc = new SelectList(dbcar.CarType_46004683_mvc, "ID", "CarType", car[0].CarType_46004683_mvc);
                return View(car[0]);
            }
            
            return View();
        }
        [HttpPost]
        public ActionResult ModifyCar(int ID,int ManufactureId, [Bind(Include = "ManufacturerName,ContactPerson,RegisteredOffice")] Manufacturer_46004683_mvc manufacturer_46004683_mvc, [Bind(Include = "Model,CarType_46004683_mvc,Engine,BHP,CarTransmissionType_46004683_mvc,Milage,Seat,AirbagDetails,BootSpace,Price")] Car_46004683_mvc car_46004683_mvc)
        {
            if (ModelState.IsValid)
            {
                car_46004683_mvc.ID = ID;
                car_46004683_mvc.ManufactureId = ManufactureId;
                manufacturer_46004683_mvc.ID = ManufactureId;
                    dbcar.Entry(manufacturer_46004683_mvc).State = EntityState.Modified;
                
                    dbcar.Entry(car_46004683_mvc).State = EntityState.Modified;
                dbcar.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.CarTransmissionType_46004683_mvc = new SelectList(dbcar.CarTransmissionType_46004683_mvc, "ID", "TransmissionName", car_46004683_mvc.CarTransmissionType_46004683_mvc);
            ViewBag.CarType_46004683_mvc = new SelectList(dbcar.CarType_46004683_mvc, "ID", "CarType",car_46004683_mvc.CarType_46004683_mvc);
            return View(car_46004683_mvc);
        }
        public ActionResult ListCar(string ManufacturerName , string CarType_46004683_mvc)
        {
            List<Car_46004683_mvc> carlist = new List<Car_46004683_mvc>();
            int a = Convert.ToInt32(CarType_46004683_mvc);
            carlist = dbcar.Car_46004683_mvc.Where(e => e.Manufacturer_46004683_mvc.ManufacturerName == ManufacturerName).Where(e => e.CarType_46004683_mvc == a).ToList();
            ViewBag.CarTransmissionType_46004683_mvc = new SelectList(dbcar.CarTransmissionType_46004683_mvc, "ID", "TransmissionName");
            ViewBag.CarType_46004683_mvc = new SelectList(dbcar.CarType_46004683_mvc, "ID", "CarType");
            return View(carlist);
        }
        public ActionResult DeleteCar (string model)
        {
            if (model != null)
            {
                Car_46004683_mvc car = dbcar.Car_46004683_mvc.Where(e => e.Model == model).Single();
                dbcar.Car_46004683_mvc.Remove(car);
                dbcar.SaveChanges();
                return RedirectToAction("Index");
            }
            return View();
        }
        //[HttpPost]
        //public ActionResult SearchCar()
        //{
        //    if(ModelState.IsValid)
        //    {

        //    }
        //}
    }
}